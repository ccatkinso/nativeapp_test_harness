def hello(): return 'Hello with requests'
