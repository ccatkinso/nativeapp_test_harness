def hello():
    return "Hello from mypkg"
